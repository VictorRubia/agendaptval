class OpcionesHomepage{

  String enlacePicto;
  String nombre;

  OpcionesHomepage(this.enlacePicto, this.nombre);

}